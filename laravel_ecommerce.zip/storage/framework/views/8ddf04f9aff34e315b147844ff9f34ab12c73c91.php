<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.includes.bread_cumb',['title'=>'DASHBOARD'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div style="height: 600px;">
                        <!--Please remove the height before using this page-->

                    </div>
                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel_ecommerce\resources\views/admin/index.blade.php ENDPATH**/ ?>