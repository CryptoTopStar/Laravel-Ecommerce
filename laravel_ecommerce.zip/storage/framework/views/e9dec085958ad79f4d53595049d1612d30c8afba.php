<?php $__env->startSection('content'); ?>

            <!-- slider area start -->
            <?php echo $__env->make('website.ecommerce.home_include.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="all-product-area mtb-45">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-3 col-lg-3 col-md-12 col-12">

                            <?php echo $__env->make('website.ecommerce.home_include.latest_deal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <!-- featured-area start -->
                            <?php echo $__env->make('website.ecommerce.home_include.featured', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!-- featured-area end -->
                            <!-- testimonils-area start -->
                            <?php echo $__env->make('website.ecommerce.home_include.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!-- testimonils-area end -->
                            <!-- blog-area start -->
                            <?php echo $__env->make('website.ecommerce.home_include.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!-- blog-area end -->
                            <!-- newsletter-area start -->
                            <?php echo $__env->make('website.ecommerce.home_include.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!-- newsletter-area start -->
                        </div>

                        <!-- product-area start -->
                        <div class="col-xl-9 col-lg-9 col-md-12 col-12">

                            
                            

                            
                            <home-section></home-section>

                            <!-- banner-area start -->
                            <div class="banner-area mtb-35">
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="single-banner">
                                            <a href="#">
                                                <img src="<?php echo e(asset('contents/website')); ?>/img/banner/1.jpg" alt="" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="single-banner">
                                            <a href="#">
                                                <img src="<?php echo e(asset('contents/website')); ?>/img/banner/2.jpg" alt="" />
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- banner-area end -->

                            <!-- tab-area start -->
                            <div class="tab-area box-shadow bg-fff">
                                <div class="product-title home3-bg text-uppercase">
                                    <i class="fa fa-check-square-o icon home3-bg2"></i>
                                    <h3>Products category</h3>
                                    <div class="tab-menu home3-tab-menu floatright hidden-xs">
                                        <ul class="nav">
                                            <li><a href="#" class="active" >Electronics</a></li>
                                            <li><a href="#" >Smartphone</a></li>
                                            <li><a href="#" >Tablets</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="tab-content">
                                    <div class="row">
                                        <?php for($i = 0; $i < 12; $i++): ?>
                                            <div class="col-md-3">
                                                <?php echo $__env->make('website.ecommerce.product.home_product_body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            </div>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                            <!-- tab-area end -->

                            <!-- banner-area start -->
                            <div class="banner-area mtb-35">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="single-banner">
                                            <a href="#">
                                                <img src="<?php echo e(asset('contents/website')); ?>/img/banner/4.jpg" alt="" />
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="single-banner">
                                            <a href="#">
                                                <img src="<?php echo e(asset('contents/website')); ?>/img/banner/5.jpg" alt="" />
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- banner-area end -->

                            <!-- mostviewed-area start -->
                            <div class="mostviewed-area mt-35 box-shadow bg-fff">
                                <div class="product-title home3-bg text-uppercase">
                                    <i class="fa fa-check-square-o icon home3-bg2"></i>
                                    <h3>Products category</h3>
                                </div>
                                <div class="row">
                                    <?php for($i = 0; $i < 12; $i++): ?>
                                        <div class="col-md-3">
                                            <?php echo $__env->make('website.ecommerce.product.home_product_body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <!-- mostviewed-area end -->
                        </div>
                        <!-- product-area end -->
                    </div>
                </div>
            </div>


            <!-- brand-area start -->
            <div class="brand-area mb-35">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                            <div class="brand-active box-shadow p-15 bg-fff">
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/1.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/2.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/3.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/1.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/4.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/5.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/6.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/7.jpg" alt="" />
                                    </a>
                                </div>
                                <div class="single-brand">
                                    <a href="#">
                                        <img src="<?php echo e(asset('contents/website')); ?>/img/brand/8.jpg" alt="" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- brand-area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.ecommerce.layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/index.blade.php ENDPATH**/ ?>