<?php $__env->startSection('content'); ?>
    <style>
        .card .table td, .card .table th {
            white-space: break-spaces;
        }
    </style>
    <div class="content-wrapper">
        <div class="container-fluid">
            <?php echo $__env->make('admin.includes.bread_cumb',['title'=>'Product Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered table-hover table-striped">
                                <tr>
                                    <td style="width: 40%">Name</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->name); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Brand</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->brand_info?$product->brand_info->name:''); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">code</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->code); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Tax</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->tax); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Price</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->price); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Sku</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->sku); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Stock</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->stock); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">discount</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->discount); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Expiration Date</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->expiration_date); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Minimum Amount</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->minimum_amount); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Free Delivery</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->free_delivery); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Total View</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->total_view); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Description</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo $product->description; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Description</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo $product->description; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Thumb Image</td>
                                    <td>:</td>
                                    <td>
                                        <img style="height: 50px;" src="/<?php echo e($product->thumb_image); ?>" alt="">
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Related Image</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><img style="height: 50px;" src="/<?php echo e($item->name); ?>" alt=""></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Category</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Sub Category</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Main Category</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->main_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Color</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Publication</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->publication; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Size</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Unit</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Vendor</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Writer</td>
                                    <td>:</td>
                                    <td>
                                        <ul class="d-flex">
                                            <?php $__currentLoopData = $product->writer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="mx-2"><?php echo e($item->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Created at</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->created_at->format('d F Y h:i:s a')); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Updated at</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->updated_at->format('d F Y h:i:s a')); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">Creator</td>
                                    <td>:</td>
                                    <td>
                                        <?php echo e($product->creator_info ? $product->creator_info->username : ''); ?>

                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--start overlay-->
            <div class="overlay"></div>
            <!--end overlay-->
        </div>
        <!-- End container-fluid-->
    </div>
    <!--End content-wrapper-->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/admin/product/view.blade.php ENDPATH**/ ?>